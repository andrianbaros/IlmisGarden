<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Love Confession 💖</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="page">

<div class="container card">
  <h1>💘 Send your love confession</h1>
  <p class="heart">❤️ 💌 💕</p>

  <form action="submit.php" method="POST" autocomplete="off">

    <!-- NAMA PENGIRIM (OPSIONAL) -->
    <label>Nama Pengirim</label>
    <input 
      type="text" 
      name="sender_name" 
      placeholder="Nama kamu (boleh dikosongkan jika anonim)"
    >

    <!-- KONTAK PENGIRIM (WAJIB) -->
    <label>Kontak Pengirim <span style="color:red">*</span></label>
    <input 
      type="text" 
      name="sender_contact" 
      required 
      placeholder="WhatsApp / Instagram / Email"
    >

    <!-- NAMA PENERIMA -->
    <label>Nama Penerima <span style="color:red">*</span></label>
    <input 
      type="text" 
      name="receiver_name" 
      required 
      placeholder="Nama orang yang kamu suka..."
    >

    <!-- KONTAK PENERIMA -->
    <label>Kontak Penerima <span style="color:red">*</span></label>
    <input 
      type="text" 
      name="receiver_contact" 
      required 
      placeholder="WhatsApp / Instagram / Email"
    >

    <!-- ALASAN -->
    <label>Alasan Mengirim Confess</label>
    <textarea 
      name="reason" 
      placeholder="Kenapa kamu mau confess? (opsional)"
    ></textarea>

    <!-- PESAN -->
    <label>Ucapan Confess 💌 <span style="color:red">*</span></label>
    <textarea 
      name="message" 
      required 
      placeholder="Tulis pesan cintamu di sini..."
    ></textarea>

    <!-- ANONIM -->
    <label style="display:flex; align-items:center; gap:8px; margin-top:15px;">
      <input type="checkbox" name="is_anonymous" value="1">
      Kirim sebagai anonim
    </label>

    <button type="submit">💝 Kirim Confession</button>
  </form>
</div>

</body>
</html>
