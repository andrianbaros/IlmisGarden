<?php
include '../db.php';

$sql = "SELECT * FROM confess ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body class="page">

<div class="container card">
  <h1>📊 Dashboard Admin</h1>

  <table border="1" width="100%" cellpadding="10" cellspacing="0">
    <tr>
      <th>Pengirim</th>
      <th>Penerima</th>
      <th>Pesan</th>
      <th>Aksi</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?= htmlspecialchars($row['sender_name']) ?></td>
        <td><?= htmlspecialchars($row['receiver_name']) ?></td>
        <td><?= htmlspecialchars(substr($row['message'], 0, 50)) ?>...</td>
        <td>
          <?php if (!$row['is_selected']) { ?>
            <a href="select.php?id=<?= $row['id'] ?>">⭐ Pilih</a>
          <?php } else { ?>
            <a href="../view.php?c=<?= $row['token'] ?>" target="_blank">
              🔗 Lihat Link
            </a>
          <?php } ?>
        </td>
      </tr>
    <?php } ?>

  </table>
</div>

</body>
</html>
