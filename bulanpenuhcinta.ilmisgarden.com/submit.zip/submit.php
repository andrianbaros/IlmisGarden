<?php
include 'db.php';

$sender_name      = $_POST['sender_name'];
$sender_contact   = $_POST['sender_contact'];
$receiver_name    = $_POST['receiver_name'];
$receiver_contact = $_POST['receiver_contact'];
$reason           = $_POST['reason'];
$message          = $_POST['message'];
$is_anonymous     = isset($_POST['is_anonymous']) ? 1 : 0;

if ($is_anonymous) {
  $sender_name = "Anonymous 💌";
}

if (
  empty($_POST['sender_contact']) ||
  empty($_POST['receiver_contact'])
) {
  die("Kontak pengirim & penerima wajib diisi ❤️");
}


// GENERATE TOKEN UNIK
$token = bin2hex(random_bytes(16));

$sql = "INSERT INTO confess 
(sender_name, sender_contact, receiver_name, receiver_contact, reason, message, is_anonymous, token)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
  "ssssssis",
  $sender_name,
  $sender_contact,
  $receiver_name,
  $receiver_contact,
  $reason,
  $message,
  $is_anonymous,
  $token
);

$stmt->execute();

// submit.php (akhir)
header("Location: thanks.php");
exit;

?>
